from scraper.login import iniciar_sesion, actualizar_carpeta_descargas
from scraper.navigator import navegar_a_descarga, navegar_a_quincena
from scraper.downloader import descargar_comprobantes,descargar_comprobantes_pw
from utils.logger import logger
from config.settings import config
from utils.file_manager import get_last_downloaded, mark_as_downloaded, is_already_downloaded

from playwright.sync_api import sync_playwright


def obtener_inicio():
    """Determina desde qué quincena y año iniciar el scraping."""
    last_downloaded = get_last_downloaded()

    if last_downloaded:  # Si hay historial, iniciar desde la última quincena registrada
        year, quincena = last_downloaded
        quincena = int(quincena) + 1  # Iniciar en la siguiente quincena
        if quincena > 24:  # Si la quincena pasa de 24, avanzar de año
            year += 1
            quincena = 1
        print(f"📌 Continuando desde la siguiente quincena: {year} - Q{quincena:02d}")
    else:  # Si no hay historial, usar el `config.ini`
        year = int(config.get("PERIODO", "inicio").split()[0])
        quincena = int(config.get("PERIODO", "inicio").split()[1])
        print(f"📌 No hay historial previo. Iniciando desde {year} - Q{quincena:02d}")
    quincena=str(quincena).zfill(2)  # Asegurar formato correcto (01, 02, ..., 24)
    return year, quincena


def main():
    year, quincena = obtener_inicio()
    with sync_playwright() as p:
        pagina = iniciar_sesion(p)
        
        if pagina:
            if is_already_downloaded(year, quincena):  # Evitar descargas repetidas
                print(f"✅ Saltando {year} - Q{quincena}, ya fue descargado.")
            else:        
                while True:        
                    exito = navegar_a_quincena(pagina,year,quincena)
            
                    if exito:
                        descargar_comprobantes_pw(pagina, year, quincena)
                    else:
                        print("❌ No hay comprobantes disponibles.")

                        input("Presiona Enter para cerrar el navegador...")  # Mantenerlo abierto para prueba
            
                        pagina.context.close()
                        break
                    quincena = str(int(quincena) + 1).zfill(2)  # Asegurar formato correcto (01, 02, ..., 24)

                # 📌 Si la quincena pasa de 24, cambiar de año y actualizar la carpeta de descargas sin cerrar sesión
                    if int(quincena) > 24:
                        print(f"📅 Cambio de año detectado: {year} ➝ {year + 1}")
                        year += 1
                        quincena = "01"  # Reiniciar quincena a 01

if __name__ == "__main__":
    main()
